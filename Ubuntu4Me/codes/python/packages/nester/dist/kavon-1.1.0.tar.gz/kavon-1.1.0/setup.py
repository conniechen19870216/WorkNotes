from distutils.core import setup
setup(
    name = 'kavon',
    version = '1.1.0',
    py_modules = ['nester'],
    author = 'kavon ma',
    author_email = 'kavon.ma@alcatel-lucent.com',
    url = 'http://www.kavonma.com',
    description = 'A simple printer of nested lists',
)
