from distutils.core import setup
setup(
    name = 'qiubai',
    version = '1.0.0',
    py_modules = ['qiubai'],
    author = 'kavon ma',
    author_email = 'kavon.ma@alcatel-lucent.com',
    url = 'https://github.com/kavonm',
    description = 'qiu shi bai ke',
)
