/*
 * =====================================================================================
 *
 *       Filename:  kavon.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2013年01月20日 23时28分59秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Kavon Ma (mn), kavon.ma@alcatel-lucent.com
 *        Company:  Alcatel-Lucent
 *
 * =====================================================================================
 */

#include <stdio.h>

void hello()
{
	printf("hello, kavon\n");
}
