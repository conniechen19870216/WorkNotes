/*
 * =====================================================================================
 *
 *       Filename:  AllTest.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2013年01月20日 23时21分02秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Kavon Ma (mn), kavon.ma@alcatel-lucent.com
 *        Company:  Alcatel-Lucent
 *
 * =====================================================================================
 */

extern "C"
{
	//IMPORT_TEST_GROUP(FirstTestGroup);
	IMPORT_TEST_GROUP(MockTestGroup);
}
