gcc -I../apue.2e.code/include/  -L../apue.2e.code/lib/  $@ -lapue
