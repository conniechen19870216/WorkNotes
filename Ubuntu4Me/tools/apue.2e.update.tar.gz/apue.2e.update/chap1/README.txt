
0. put chap1 to the same dir as dir apue.2e.code/

|-- apue.2e.code
|-- chap1

1. how to build

run ./bld.sh <filename>

2. how to run

run ./a.out to see how the program run
