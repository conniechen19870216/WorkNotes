
0. put chap<x> to the same dir as dir apue.2e.code/

|-- apue.2e.code
|-- chap<x>

1. how to build

run ./bld.sh <filename>

2. how to run

run ./a.out to see how the program run


####
awk -f 1.awk >1.c
