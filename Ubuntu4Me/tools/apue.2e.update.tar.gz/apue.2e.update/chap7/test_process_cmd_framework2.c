#include "apue.h"
#include <setjmp.h>

#define	TOK_ADD	   5

void	do_line(char *);
void	cmd_add(void);
int		get_token(void);

jmp_buf jmpbuffer;

int
main(void)
{
	char	line[MAXLINE];
    
    if (setjmp(jmpbuffer) != 0)
    {
         printf("error\n");
    }
	while (fgets(line, MAXLINE, stdin) != NULL)
    {
        //printf("processing line:%s\n", line);
		do_line(line);
    }
	exit(0);
}

char	*tok_ptr;		/* global pointer for get_token() */

void
do_line(char *ptr)		/* process one line of input */
{
	int		cmd;

	tok_ptr = ptr;
	while ((cmd = get_token()) > 0) {
        //fprintf(stderr, "do_line: get cmd:%d\n", cmd);
		switch (cmd) {	/* one case for each command */
		case TOK_ADD:
				cmd_add();
				break;
        default:
                break;
		}
	}
}

void
cmd_add(void)
{
	int		token;

	token = get_token();
	/* rest of processing for this command */
    //fprintf(stderr, "cmd_add: processing token:%d\n", token);
    if (token < 0) // an error has occurred
    {
       longjmp(jmpbuffer, 1);
    }
}

int
get_token(void)
{
   static int n = -5;
   n = -n;
	/* fetch next token from line pointed to by tok_ptr */
   //printf("get_token: get token :%d\n", 5);
   return n;
}
