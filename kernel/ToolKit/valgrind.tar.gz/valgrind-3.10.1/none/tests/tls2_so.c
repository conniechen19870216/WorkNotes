#include <config.h>

#ifdef HAVE_TLS
__thread int so_extern;
#endif
