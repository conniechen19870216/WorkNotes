
/* Doesn't do anything.  The point of this is to test for the presence
   of a couple of symbols in libc.so.  See the .vgtest files. */

int main ( void )
{
  return 0;
}
